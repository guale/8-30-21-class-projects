package com.tts.TTTwitter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TtTwitterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TtTwitterApplication.class, args);
	}

}
